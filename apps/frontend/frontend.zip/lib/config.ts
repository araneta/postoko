export const BASE_URL = __DEV__
  ? 'http://localhost:3000/api'
  : 'https://postoko.aldoapp.com/api';